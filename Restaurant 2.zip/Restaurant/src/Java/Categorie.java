package Java;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author joni
 *///

public class Categorie {
     private int ID;
     private String Name;

     public Categorie(int pID, String pName){
        this.ID = pID;
        this.Name = pName;  
     }
      public int getID() {
            return ID;
        }
        public void setID(int ID) {
            this.ID = ID;
        }
        public String getName() {
            return Name;
        }
        public void setName(String Name) {
            this.Name = Name;
        }
        
        
        
    Categorie(int aInt) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    Categorie() {}
    
       
}
