package JFrames;

import Java.Employee;
import java.sql.Statement;
import com.mysql.jdbc.Driver;
import java.awt.Color;
import java.awt.Image;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
/**
 *
 * @author joni
 */
public class Employees extends javax.swing.JFrame {

    Color ExitBack = new Color(74, 27, 1);
    Color EnterBack = new Color(92, 46, 1);

    Connection con = null;
    ResultSet rs = null;
    PreparedStatement pst = null;

    /**
     * Creates new form Employees
     */
    public Employees() {
        initComponents();
        this.setLocationRelativeTo(null);
        ShowEmployeeInJTable();
        addBtn.setEnabled(false);
        updateBtn.setEnabled(false);
        removeBtn.setEnabled(false);
        clearBtn.setEnabled(false);
        // Column sizes for the jTable
        JTableEmployee.getColumnModel().getColumn(0).setPreferredWidth(25);
        JTableEmployee.getColumnModel().getColumn(1).setPreferredWidth(60);
        JTableEmployee.getColumnModel().getColumn(2).setPreferredWidth(100);
        JTableEmployee.getColumnModel().getColumn(3).setPreferredWidth(68);
        JTableEmployee.getColumnModel().getColumn(4).setPreferredWidth(60);
        JTableEmployee.getColumnModel().getColumn(5).setPreferredWidth(30);
        JTableEmployee.getColumnModel().getColumn(6).setPreferredWidth(50);
        JTableEmployee.getColumnModel().getColumn(7).setPreferredWidth(30);
        JTableEmployee.getColumnModel().getColumn(8).setPreferredWidth(150);

    }
  
    String ImgPath = null;
    
    int pos = 0; // Position of record in table declaration
                 // This will be used for the navigation buttons to go from one employee to another.
    public Connection getConnection() {
        Connection con = null;
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3307/Restaurant", "root", "");
            return con;
        } catch (SQLException ex) {
            Logger.getLogger(Employees.class.getName()).log(Level.SEVERE, null, ex);
            return null;

        }
    }

    // Validation rules that must be satisfied in order to be able to add and update an empolyee
    public void validateField() {
        String Name = txtName.getText();
        String Email = txtEmail.getText();
        String Number = txtPhoneNumber.getText();
        String Salary = txtSalary.getText();
        String Address = txtAddress.getText();

        if (!Name.equals("") && !Email.equals("") && !Number.equals("") && !Salary.equals("") && !Address.equals("")) {
            addBtn.setEnabled(true);
        } else {
            addBtn.setEnabled(false);
        }
    }

    public void validateFields() {
        String Name = txtName.getText();
        String Email = txtEmail.getText();
        String Number = txtPhoneNumber.getText();
        String Salary = txtSalary.getText();
        String Address = txtAddress.getText();

        if (!Name.equals("") && !Email.equals("") && !Number.equals("") && !Salary.equals("") && !Address.equals("")) {
            updateBtn.setEnabled(true);
        } else {
            updateBtn.setEnabled(false);
        }
    }

    public void validateFieldss() {
        String Name = txtName.getText();
        String Email = txtEmail.getText();
        String Number = txtPhoneNumber.getText();
        String Salary = txtSalary.getText();
        String Address = txtAddress.getText();

        if (!Name.equals("") && !Email.equals("") && !Number.equals("") && !Salary.equals("") && !Address.equals("")) {
            removeBtn.setEnabled(true);
        } else {
            removeBtn.setEnabled(false);
        }
    }

    public void validateFieldsss() {
        String Name = txtName.getText();
        String Email = txtEmail.getText();
        String Number = txtPhoneNumber.getText();
        String Salary = txtSalary.getText();
        String Address = txtAddress.getText();

        if (!Name.equals("") || !Email.equals("") || !Number.equals("") || !Salary.equals("") || !Address.equals("")) {
            clearBtn.setEnabled(true);
        } else {
            clearBtn.setEnabled(false);
        }
    }
    
//  Credits: Maurice Muteti on YouTube whose code I modified from this video https://youtu.be/33jZhuO3yeE
//  Using an ArrayList to store the data from the MySQL database 'Employee' into our jTable here.
//  We are also using the getters from our class 'Employee' to perform this action.     
    public ArrayList<Employee> getEmployeeList() {

        ArrayList<Employee> employeeList = new ArrayList<Employee>(); //import the java.util.ArrayList;
        Connection con = getConnection();
        String query = "SELECT * FROM `Employee`"; //the * saves us the trouble of having to type all the column names.

        Statement st; //import the java.sql.Statement
        ResultSet rs; //import the java.sql.ResultSet

        try {
            st = con.createStatement();
            rs = st.executeQuery(query);
            Employee employee; 
            while (rs.next()) { //this method loops through results so provide the getters inside the 'Employee' object.

                employee = new Employee(
                        rs.getInt("WorkerID"),
                        rs.getString("Name"),
                        rs.getString("Email"),
                        rs.getString("DOB"),
                        rs.getInt("PhoneNumber"),
                        rs.getString("Gender"),
                        rs.getString("Position"),
                        Float.parseFloat(rs.getString("Salary")), //needs to be written this way due to the data type.
                        rs.getString("Address"),
                        rs.getBytes("Photo")
                );
                employeeList.add(employee); //add to the list the employee.
            }
        } catch (SQLException ex) {
            Logger.getLogger(Employees.class.getName()).log(Level.SEVERE, null, ex);
        }
        return employeeList;
    }
    
    //Populating the jtable using the ArrayList
    public void ShowEmployeeInJTable() {

        ArrayList<Employee> list = getEmployeeList(); //Calling the method for the ArrayList above.

        DefaultTableModel model = (DefaultTableModel) JTableEmployee.getModel(); //import the java.util.DefaultTableModel.

        model.setRowCount(0); //So that it doesn't add all the previous jTable data again but only the current data being entered.
        Object[] row = new Object[9]; //The number '9' represents the number of rows. 

        for (int i = 0; i < list.size(); i-=-1) { //for loop iterates through the object's rows when less than 9. 'i' is the index.
            row[0] = list.get(i).getWorkerID();
            row[1] = list.get(i).getName();
            row[2] = list.get(i).getEmail();
            row[3] = list.get(i).getDOB();
            row[4] = list.get(i).getPhoneNumber();
            row[5] = list.get(i).getGender();
            row[6] = list.get(i).getPosition();
            row[7] = list.get(i).getSalary();
            row[8] = list.get(i).getAddress();
            model.addRow(row); 
        }       
//            rows[i][0] = list.get(i).getWorkerID();
//            rows[i][1] = list.get(i).getName();
//            rows[i][2] = list.get(i).getEmail();
//            rows[i][3] = list.get(i).getDOB();
//            rows[i][4] = list.get(i).getPhoneNumber();
//            rows[i][5] = list.get(i).getGender();
//            rows[i][6] = list.get(i).getPosition();
//            rows[i][7] = list.get(i).getSalary();
//            rows[i][8] = list.get(i).getAddress();
//            rows[i][9] = list.get(i).getPhoto();
//
//        MyModel model = new MyModel(rows, columnName);
//        JTableEmployee.setModel(model);
          JTableEmployee.setRowHeight(30);
    }

    public void showEmployee(int index) {

        txtWorkerID.setText(Integer.toString(getEmployeeList().get(index).getWorkerID()));
        txtName.setText(getEmployeeList().get(index).getName());
        txtEmail.setText(getEmployeeList().get(index).getEmail());

        try {
            Date DOB = null;
            DOB = new SimpleDateFormat("yyyy-MM-dd").parse((String) getEmployeeList().get(index).getDOB());
            txtDOB.setDate(DOB);
        } catch (ParseException ex) {
            Logger.getLogger(Employees.class.getName()).log(Level.SEVERE, null, ex);
        }

        txtPhoneNumber.setText(Integer.toString(getEmployeeList().get(index).getPhoneNumber()));

        String Gender = getEmployeeList().get(index).getGender();
        if (Gender.equals("Male")) {
            male.setSelected(true);
            female.setSelected(false);
        } else if (Gender.equals("Female")) {
            female.setSelected(true);
            male.setSelected(false);
        }

        txtPosition.setSelectedItem(getEmployeeList().get(index).getPosition());
        txtSalary.setText(Float.toString(getEmployeeList().get(index).getSalary()));
        txtAddress.setText(getEmployeeList().get(index).getAddress());
        lbl_img.setIcon(ResizeImage(null, getEmployeeList().get(index).getPhoto()));
    }

    public void Connect() {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3307/Restaurant", "root", "");

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Driver.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Driver.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // Check input fields verification
    public boolean checkInputs() {
        if (txtName.getText() == null || txtEmail.getText() == null
                || txtDOB.getDate() == null || txtPhoneNumber.getText() == null
                || txtPosition.getSelectedItem().toString() == null
                || txtSalary.getText() == null || txtAddress.getText() == null) {
            return false;
        } else {
            try {
                Float.parseFloat(txtSalary.getText());
                return true;
            } catch (Exception ex) {
                return false;
            }
        }
    }

//     * This method is called from within the constructor to initialize the form.
//     * WARNING: Do NOT modify this code. The content of this method is always
//     * regenerated by the Form Editor.
//     */
//    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        male = new javax.swing.JRadioButton();
        female = new javax.swing.JRadioButton();
        txtDOB = new com.toedter.calendar.JDateChooser();
        addBtn = new javax.swing.JButton();
        removeBtn = new javax.swing.JButton();
        updateBtn = new javax.swing.JButton();
        txtPosition = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtAddress = new javax.swing.JTextArea();
        jLabel13 = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        txtName = new javax.swing.JTextField();
        txtSalary = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txtWorkerID = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        txtPhoneNumber = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        txtSearch = new javax.swing.JTextField();
        ImageBtn = new javax.swing.JButton();
        lbl_img = new javax.swing.JLabel();
        previousBtn = new javax.swing.JButton();
        nextBtn = new javax.swing.JButton();
        firstBtn = new javax.swing.JButton();
        lastBtn = new javax.swing.JButton();
        clearBtn = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        JTableEmployee = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        panelBack = new javax.swing.JPanel();
        lblBack = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(102, 51, 0, 130));

        jLabel5.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Name:");

        jLabel7.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Email:");

        jLabel8.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Date of birth:");

        jLabel10.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Address:");

        jLabel11.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Gender:");

        jLabel12.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Position:");

        male.setBackground(new java.awt.Color(102, 51, 0));
        male.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        male.setForeground(new java.awt.Color(255, 255, 255));
        male.setText("Male");
        male.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                maleActionPerformed(evt);
            }
        });

        female.setBackground(new java.awt.Color(102, 51, 0));
        female.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        female.setForeground(new java.awt.Color(255, 255, 255));
        female.setText("Female");
        female.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                femaleActionPerformed(evt);
            }
        });

        txtDOB.setDateFormatString("yyyy-MM-dd");
        txtDOB.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtDOBKeyReleased(evt);
            }
        });

        addBtn.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        addBtn.setText("Add");
        addBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addBtnActionPerformed(evt);
            }
        });

        removeBtn.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        removeBtn.setText("Remove");
        removeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeBtnActionPerformed(evt);
            }
        });

        updateBtn.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        updateBtn.setText("Update");
        updateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBtnActionPerformed(evt);
            }
        });

        txtPosition.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        txtPosition.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Manager", "Chef", "Waiter", "Waitress", "Dish cleaner", "Janitor", "Security", "Cashier" }));

        txtAddress.setColumns(20);
        txtAddress.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        txtAddress.setRows(5);
        txtAddress.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtAddressKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(txtAddress);

        jLabel13.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Salary:");

        txtEmail.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        txtEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEmailActionPerformed(evt);
            }
        });
        txtEmail.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtEmailKeyReleased(evt);
            }
        });

        txtName.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        txtName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNameActionPerformed(evt);
            }
        });
        txtName.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtNameKeyReleased(evt);
            }
        });

        txtSalary.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        txtSalary.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSalaryActionPerformed(evt);
            }
        });
        txtSalary.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtSalaryKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtSalaryKeyTyped(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("   Employee ID photo:");
        jLabel6.setToolTipText("");

        jLabel14.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Worker ID:");

        txtWorkerID.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        txtWorkerID.setEnabled(false);
        txtWorkerID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtWorkerIDActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Phone Number:");

        txtPhoneNumber.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        txtPhoneNumber.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPhoneNumberActionPerformed(evt);
            }
        });
        txtPhoneNumber.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtPhoneNumberKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtPhoneNumberKeyTyped(evt);
            }
        });

        jLabel16.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Enter a search value:");

        txtSearch.setBackground(new java.awt.Color(225, 255, 255));
        txtSearch.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        txtSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtSearchMouseClicked(evt);
            }
        });
        txtSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSearchActionPerformed(evt);
            }
        });
        txtSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtSearchKeyReleased(evt);
            }
        });

        ImageBtn.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        ImageBtn.setText("Upload Image");
        ImageBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ImageBtnActionPerformed(evt);
            }
        });

        lbl_img.setOpaque(true);

        previousBtn.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        previousBtn.setText("<");
        previousBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                previousBtnActionPerformed(evt);
            }
        });

        nextBtn.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        nextBtn.setText(">");
        nextBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextBtnActionPerformed(evt);
            }
        });

        firstBtn.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        firstBtn.setText("<-");
        firstBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                firstBtnActionPerformed(evt);
            }
        });

        lastBtn.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        lastBtn.setText("->");
        lastBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lastBtnActionPerformed(evt);
            }
        });

        clearBtn.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        clearBtn.setText("Clear All");
        clearBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(21, 21, 21)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel16)
                                        .addGap(18, 18, 18)
                                        .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel14)
                                        .addGap(18, 18, 18)
                                        .addComponent(txtWorkerID, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel15))))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(23, 23, 23)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel7)
                                            .addComponent(jLabel5))
                                        .addGap(18, 18, 18)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel8)
                                        .addGap(18, 18, 18)
                                        .addComponent(txtDOB, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(34, 34, 34)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(19, 19, 19)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel13)
                                            .addComponent(jLabel11)))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel12)
                                        .addGap(2, 2, 2)))))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtPhoneNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(clearBtn))
                        .addGap(14, 14, 14))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(male)
                                .addGap(18, 18, 18)
                                .addComponent(female))
                            .addComponent(txtPosition, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtSalary, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(7, 7, 7))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addComponent(addBtn)
                        .addGap(18, 18, 18)
                        .addComponent(updateBtn)
                        .addGap(18, 18, 18)
                        .addComponent(removeBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(firstBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(previousBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(nextBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lastBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(109, 109, 109)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel6)
                            .addComponent(ImageBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 203, Short.MAX_VALUE)
                            .addComponent(lbl_img, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(62, 62, 62))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(29, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbl_img, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ImageBtn)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(clearBtn))
                .addGap(23, 23, 23)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(txtWorkerID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15)
                    .addComponent(txtPhoneNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(male)
                    .addComponent(female))
                .addGap(21, 21, 21)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12)
                    .addComponent(txtPosition, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtSalary, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel13)
                        .addComponent(jLabel10))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtDOB, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(removeBtn)
                    .addComponent(updateBtn)
                    .addComponent(addBtn)
                    .addComponent(previousBtn)
                    .addComponent(nextBtn)
                    .addComponent(firstBtn)
                    .addComponent(lastBtn))
                .addGap(8, 8, 8))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 1030, 370));

        JTableEmployee.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Worker ID", "Name", "Email", "DOB", "Phone Number", "Gender", "Position", "Salary", "Address"
            }
        ));
        JTableEmployee.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                JTableEmployeeMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(JTableEmployee);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 450, 1000, 360));

        jPanel3.setBackground(new java.awt.Color(92, 46, 1));
        jPanel3.setForeground(new java.awt.Color(74, 27, 1));

        jLabel9.setFont(new java.awt.Font("Lucida Grande", 1, 48)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Olive & Bread");

        panelBack.setBackground(new java.awt.Color(92, 46, 1));

        lblBack.setIcon(new javax.swing.ImageIcon("/Users/joni/Downloads/icons8-go-back-64.png")); // NOI18N
        lblBack.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        lblBack.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblBackMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblBackMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblBackMouseExited(evt);
            }
        });

        javax.swing.GroupLayout panelBackLayout = new javax.swing.GroupLayout(panelBack);
        panelBack.setLayout(panelBackLayout);
        panelBackLayout.setHorizontalGroup(
            panelBackLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelBackLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(lblBack))
        );
        panelBackLayout.setVerticalGroup(
            panelBackLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblBack, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 610, Short.MAX_VALUE)
                .addComponent(panelBack, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelBack, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1020, 80));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/cooking (3).jpg"))); // NOI18N
        jLabel3.setText(" ");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1020, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1021, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void maleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_maleActionPerformed
        // TODO add your handling code here:
        gender = "Male";
        male.setSelected(true);
        female.setSelected(false);
    }//GEN-LAST:event_maleActionPerformed

    private void femaleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_femaleActionPerformed
        // TODO add your handling code here:
        gender = "Male";
        male.setSelected(false);
        female.setSelected(true);
    }//GEN-LAST:event_femaleActionPerformed

    private void txtEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEmailActionPerformed

    private void txtNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNameActionPerformed

    private void txtWorkerIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtWorkerIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtWorkerIDActionPerformed

    private void txtPhoneNumberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPhoneNumberActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPhoneNumberActionPerformed

    private void txtSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSearchActionPerformed

    private void addBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addBtnActionPerformed
        // TODO add your handling code here:

        if (checkInputs() && ImgPath != null) {

            try {
                Connection con = getConnection();
                PreparedStatement ps = con.prepareStatement("insert into Employee (Name, Email, DOB, PhoneNumber, Gender, Position, Salary, Address, Photo)"
                        + "values(?,?,?,?,?,?,?,?,?)");
                ps.setString(1, txtName.getText());
                ps.setString(2, txtEmail.getText());

                SimpleDateFormat SDF = new SimpleDateFormat("yyyy-MM-dd");
                String DOB = SDF.format(txtDOB.getDate());
                ps.setString(3, DOB);

                ps.setString(4, txtPhoneNumber.getText());

                if (male.isSelected()) {
                    gender = "Male";
                } else if (female.isSelected()) {
                    gender = "Female";
                }

                ps.setString(5, gender);

                ps.setString(6, txtPosition.getSelectedItem().toString());
                ps.setString(7, txtSalary.getText());
                ps.setString(8, txtAddress.getText());

                try {
                    InputStream img = new FileInputStream(new File(ImgPath));
                    ps.setBlob(9, img);
                    ps.executeUpdate();
                    ShowEmployeeInJTable();

                    JOptionPane.showMessageDialog(null, "Employee Added!");

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                    Logger.getLogger(Employees.class.getName()).log(Level.SEVERE, null, ex);
                }
            } catch (SQLException ex) {
                Logger.getLogger(Employees.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, "Employee Not Added!");

            }
        } else {
            JOptionPane.showMessageDialog(null, "Employee already exists!");
        }
        
        // Display the inputted results as a HashMap would
        System.out.println("Name =>" + txtName.getText());
        System.out.println("Email =>" + txtEmail.getText());
        System.out.println("PhoneNumber =>" + txtPhoneNumber.getText());
        System.out.println("Gender =>" + gender);
        System.out.println("Position =>" + txtPosition.getSelectedItem().toString());
        System.out.println("Salary =>" + txtSalary.getText());
        System.out.println("Address =>" + txtAddress.getText());
        System.out.println("Photo url =>" + ImgPath);
        
        // Reset/empty feilds after an employee is added
        txtWorkerID.setText("");
        txtName.setText("");
        txtEmail.setText("");
        txtDOB.setDate(null);
        txtPhoneNumber.setText("");
        male.setSelected(false);
        female.setSelected(false);
        txtPosition.setSelectedIndex(0);
        txtSalary.setText("");
        lbl_img.setIcon(null);
        txtAddress.setText("");
        txtSearch.setText("");

    }//GEN-LAST:event_addBtnActionPerformed

    private void txtSearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSearchKeyReleased
        //Searches (Filters) for an Employee using the 'Search' jtextfield.
        //Credit Noureddine on Youtube. Video link: https://youtu.be/DJEXpgLyAtQ
        DefaultTableModel dtm = (DefaultTableModel) JTableEmployee.getModel(); //import the javax.swing.table.DefaultTableModel.
        TableRowSorter<DefaultTableModel> tr = new TableRowSorter<DefaultTableModel>(dtm); //import javax.swing.table.TableRowSorter.
        String search = txtSearch.getText();
        JTableEmployee.setRowSorter(tr);
        tr.setRowFilter(RowFilter.regexFilter(search)); //import javax.swing.RowFilter.
        
    }//GEN-LAST:event_txtSearchKeyReleased

    private void removeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeBtnActionPerformed
        // TODO add your handling code here:
        if (!txtWorkerID.getText().equals("")) {
            Connection con = getConnection();
            try {
                PreparedStatement ps = con.prepareStatement("delete FROM Employee where WorkerID = ?");
                int WorkerID = Integer.parseInt(txtWorkerID.getText());
                ps.setInt(1, WorkerID);
                ps.executeUpdate();
                ShowEmployeeInJTable();

                JOptionPane.showMessageDialog(null, "Employee Removed!");

            } catch (SQLException ex) {
                Logger.getLogger(Employees.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, "Employee Not Removed!");

            }

        }

    }//GEN-LAST:event_removeBtnActionPerformed

    private void txtPhoneNumberKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPhoneNumberKeyTyped
        // Validation: Only numbers
        if (!Character.isDigit(evt.getKeyChar())) {
            evt.consume();
        }
    }//GEN-LAST:event_txtPhoneNumberKeyTyped
    //Source: https://youtu.be/mdPNwrQ8kxU 1BestCsharp blog on YouTube. 
    //Resize image to fit any dimention into the jLabel without distorting its quality
    public ImageIcon ResizeImage(String imagePath, byte[] pic) {
        ImageIcon myImage = null; //import javax.swing.ImageIcon

        if (imagePath != null) { //We initialized the imagePath String to be "null"
            myImage = new ImageIcon(imagePath); //If null show the image's filepath
        } else {
            myImage = new ImageIcon(pic);//Otherwise show the picture 
        }
        Image img = myImage.getImage();
        Image img2 = img.getScaledInstance(lbl_img.getWidth(), lbl_img.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon image = new ImageIcon(img2);
        return image; //Show the output of the image on the jLabel "lbl_img".
    }

    private void ImageBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ImageBtnActionPerformed
        //When the image button is pressed. 
        //import javax.swing.JFileChooser to allow importing a file onto the jLabel
        JFileChooser file = new JFileChooser();// JFileChooser method allows the user to choose any file they want.
        file.setCurrentDirectory(new File(System.getProperty("user.home")));// Redirects the user to their home page.
                                                                            // Can also be written as "user.dir"
        //Filter that restricts the users choices only for image files to be selected.
        FileNameExtensionFilter filter = new FileNameExtensionFilter("*.image", "jpg", "png");
        file.addChoosableFileFilter(filter); //import javax.swing.filechooser.FileNameExtensionFilter
        int result = file.showSaveDialog(null);//The method showSaveDialog() returns "0" if is successfull.
        if (result == JFileChooser.APPROVE_OPTION) { //If the user selects an image file, their option will be approved.
            File selectedFile = file.getSelectedFile();
            String path = selectedFile.getAbsolutePath(); //The filepath of the image file
            lbl_img.setIcon(ResizeImage(path, null));
            ImgPath = path;
        } else { //Error message if user tries selecting a file that is not an image file.
            System.out.println("Please select an image file!");
        }                
    }//GEN-LAST:event_ImageBtnActionPerformed

    private void updateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateBtnActionPerformed
        // Updates an existing users information
        // Source: 1BestCsharp blog https://youtu.be/e-hAIY9QtqA
        if (checkInputs() && txtWorkerID.getText() != null) {
            String UpdateQuery = null;
            PreparedStatement ps = null;
            Connection con = getConnection();

            if (ImgPath == null) {
                try {
                    UpdateQuery = "update Employee set Name = ?, Email = ?, DOB = ?, PhoneNumber = ?, Gender = ?, Position = ?, Salary = ?, Address = ?, Photo = ? where WorkerID = ?";

                    ps = con.prepareStatement(UpdateQuery);

                    ps.setString(1, txtName.getText());
                    ps.setString(2, txtEmail.getText());

                    SimpleDateFormat SDF = new SimpleDateFormat("yyyy-MM-dd");
                    String DOB = SDF.format(txtDOB.getDate());

                    ps.setString(3, DOB);

                    ps.setString(4, txtPhoneNumber.getText());

                    if (male.isSelected()) {
                        gender = "Male";
                    } else if (female.isSelected()) {
                        gender = "Female";
                    }
                    ps.setString(5, gender);

                    ps.setString(6, txtPosition.getSelectedItem().toString());
                    ps.setString(7, txtSalary.getText());
                    ps.setString(8, txtAddress.getText());

                    ps.setInt(9, Integer.parseInt(txtWorkerID.getText()));

                    ps.executeUpdate();
                    ShowEmployeeInJTable();

                    JOptionPane.showMessageDialog(this, "Employee Information Updated!");

                } catch (SQLException ex) {
                    Logger.getLogger(Employees.class.getName()).log(Level.SEVERE, null, ex);
                    JOptionPane.showMessageDialog(null, "Employee Information Not Updated!");

                }
            }//for updating image
            else {

                try {
                    InputStream img = new FileInputStream(new File(ImgPath));

                    UpdateQuery = "update Employee set Name = ?, Email = ?, DOB = ?, PhoneNumber = ?, Gender = ?, Position = ?, Salary = ?, Address = ?, Photo = ? where WorkerID = ?";

                    ps = con.prepareStatement(UpdateQuery);

                    ps.setString(1, txtName.getText());
                    ps.setString(2, txtEmail.getText());

                    SimpleDateFormat SDF = new SimpleDateFormat("yyyy-MM-dd");
                    String DOB = SDF.format(txtDOB.getDate());

                    ps.setString(3, DOB);

                    ps.setString(4, txtPhoneNumber.getText());

                    if (male.isSelected()) {
                        gender = "Male";
                    } else if (female.isSelected()) {
                        gender = "Female";
                    }
                    ps.setString(5, gender);

                    ps.setString(6, txtPosition.getSelectedItem().toString());
                    ps.setString(7, txtSalary.getText());
                    ps.setString(8, txtAddress.getText());

                    ps.setBlob(9, img);

                    ps.setInt(10, Integer.parseInt(txtWorkerID.getText()));

                    ps.executeUpdate();
                    ShowEmployeeInJTable();

                    JOptionPane.showMessageDialog(this, "Employee Information Updated!");

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                    Logger.getLogger(Employees.class.getName()).log(Level.SEVERE, null, ex);
                    JOptionPane.showMessageDialog(null, "Employee Information Not Updated!");

                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "Empty field(s) present!");
        }

    }//GEN-LAST:event_updateBtnActionPerformed

    private void JTableEmployeeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JTableEmployeeMouseClicked
        // TODO add your handling code here:

        int index = JTableEmployee.getSelectedRow();
        showEmployee(index);

        addBtn.setEnabled(true);
        updateBtn.setEnabled(true);
        removeBtn.setEnabled(true);
        clearBtn.setEnabled(true);
    }//GEN-LAST:event_JTableEmployeeMouseClicked

    private void txtSalaryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSalaryActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSalaryActionPerformed

    private void txtSalaryKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSalaryKeyTyped
        // TODO add your handling code here:
        if (!Character.isDigit(evt.getKeyChar())) {
            evt.consume();
        }
    }//GEN-LAST:event_txtSalaryKeyTyped

    private void firstBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_firstBtnActionPerformed
        // TODO add your handling code here:
        pos = 0;
        showEmployee(pos);
    }//GEN-LAST:event_firstBtnActionPerformed

    private void lastBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lastBtnActionPerformed
        // TODO add your handling code here:
        pos = getEmployeeList().size() - 1;
        showEmployee(pos);
    }//GEN-LAST:event_lastBtnActionPerformed

    private void nextBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextBtnActionPerformed
        // TODO add your handling code here:
        pos++;

        if (pos >= getEmployeeList().size()) {
            pos = getEmployeeList().size() - 1;
        }
        showEmployee(pos);
    }//GEN-LAST:event_nextBtnActionPerformed

    private void previousBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_previousBtnActionPerformed
        // TODO add your handling code here:
        pos--;

        if (pos < 0) {
            pos = 0;
        }
        showEmployee(pos);
    }//GEN-LAST:event_previousBtnActionPerformed

    private void txtSearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtSearchMouseClicked
        // TODO add your handling code here:
        txtSearch.setText("");
    }//GEN-LAST:event_txtSearchMouseClicked

    private void clearBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearBtnActionPerformed
        // TODO add your handling code here:
        txtWorkerID.setText("");
        txtName.setText("");
        txtEmail.setText("");
        txtDOB.setDate(null);
        txtPhoneNumber.setText("");
        male.setSelected(false);
        female.setSelected(false);
        txtPosition.setSelectedIndex(0);
        txtSalary.setText("");
        lbl_img.setIcon(null);
        txtAddress.setText("");
        txtSearch.setText("");


    }//GEN-LAST:event_clearBtnActionPerformed

    private void lblBackMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblBackMouseEntered
        // TODO add your handling code here:
        panelBack.setBackground(ExitBack);
    }//GEN-LAST:event_lblBackMouseEntered

    private void lblBackMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblBackMouseExited
        // TODO add your handling code here:
        panelBack.setBackground(EnterBack);
    }//GEN-LAST:event_lblBackMouseExited

    private void lblBackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblBackMouseClicked
        // TODO add your handling code here:
        AdminPage Admin = new AdminPage();
        Admin.setVisible(true);
        dispose();
    }//GEN-LAST:event_lblBackMouseClicked

    private void txtNameKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNameKeyReleased
        // TODO add your handling code here:
        validateField();
        validateFields();
        validateFieldss();
        validateFieldsss();
    }//GEN-LAST:event_txtNameKeyReleased

    private void txtEmailKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtEmailKeyReleased
        // TODO add your handling code here:
        validateField();
        validateFields();
        validateFieldss();
        validateFieldsss();
    }//GEN-LAST:event_txtEmailKeyReleased

    private void txtDOBKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDOBKeyReleased
        // TODO add your handling code here:
        validateField();
        validateFields();
        validateFieldss();
        validateFieldsss();
    }//GEN-LAST:event_txtDOBKeyReleased

    private void txtPhoneNumberKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPhoneNumberKeyReleased
        // TODO add your handling code here:
        validateField();
        validateFields();
        validateFieldss();
        validateFieldsss();
    }//GEN-LAST:event_txtPhoneNumberKeyReleased

    private void txtSalaryKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSalaryKeyReleased
        // TODO add your handling code here:
        validateField();
        validateFields();
        validateFieldss();
        validateFieldsss();
    }//GEN-LAST:event_txtSalaryKeyReleased

    private void txtAddressKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtAddressKeyReleased
        // TODO add your handling code here:
        validateField();
        validateFields();
        validateFieldss();
        validateFieldsss();
    }//GEN-LAST:event_txtAddressKeyReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Employees.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Employees.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Employees.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Employees.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Employees().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ImageBtn;
    private javax.swing.JTable JTableEmployee;
    private javax.swing.JButton addBtn;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.JButton clearBtn;
    private javax.swing.JRadioButton female;
    private javax.swing.JButton firstBtn;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton lastBtn;
    private javax.swing.JLabel lblBack;
    private javax.swing.JLabel lbl_img;
    private javax.swing.JRadioButton male;
    private javax.swing.JButton nextBtn;
    private javax.swing.JPanel panelBack;
    private javax.swing.JButton previousBtn;
    private javax.swing.JButton removeBtn;
    private javax.swing.JTextArea txtAddress;
    private com.toedter.calendar.JDateChooser txtDOB;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtPhoneNumber;
    private javax.swing.JComboBox<String> txtPosition;
    private javax.swing.JTextField txtSalary;
    private javax.swing.JTextField txtSearch;
    private javax.swing.JTextField txtWorkerID;
    private javax.swing.JButton updateBtn;
    // End of variables declaration//GEN-END:variables

    // Declaration of image (BLOB) variables
    private ImageIcon format = null;
    
    String filename = null;
    
    byte[] person_image = null;

    private String gender;

    //private Connection getConnection() {
    //    throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    //}
    private static class DbUtils {

        private static TableModel resultSetToTableMModel(ResultSet rs) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private static TableModel resultSetToTableModel(ResultSet rs) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        public DbUtils() {
        }
    }
}
