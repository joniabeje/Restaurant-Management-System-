/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package JFrames;

import java.util.Date;
import com.mysql.cj.jdbc.Driver;
import com.mysql.cj.jdbc.result.ResultSetMetaData;
import java.awt.BorderLayout;
import java.awt.Color;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;

/**
 *
 * @author joni
 */
public class AdminPage extends javax.swing.JFrame implements Runnable{
                     //inheritence              //implements Runnable 
                                             //to create the thread below
    int hour, minute, second;
    int day, month, year;
    String timestr, yearstr;
 
// Colors are used throughout the program to give the appearance that something is being navigated upon before being clicked
Color EnterColor = new Color(0,0,0);   
Color ExitColor = new Color(78,78,78);
Color LogoutEnterColor = new Color(86,85,167);
Color LogoutExitColor = new Color(129,129,243);
Color EnterBack = new Color(220,44,0);   
Color ExitBack = new Color(163,43,13);
    /**
     * Creates new form AdminPage
     */
    public AdminPage() {  // Constructor
        
        initComponents();
        showPieChart();
        setDataToCards();
        CustomerLoad();
        SalesLoad();
        MessagesLoad();
        Connect();
        
        Thread t = new Thread(this); //multithreading to execute the start method below
        t.start(); //You may need to comment the clock because its making the laptop overheat because its an overridden function!

        JTableSales.setRowHeight(20);
        JTableCustomer.setRowHeight(20);
        JTableMessage.setRowHeight(50);
        JTableMessage.getColumnModel().getColumn(0).setPreferredWidth(3);
        JTableMessage.getColumnModel().getColumn(1).setPreferredWidth(50);
    }

    Connection con;
    PreparedStatement pst;
    ResultSet rs;
    
    public void Connect(){
     
        try {    
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3307/Restaurant", "root", "");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Driver.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Driver.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
      public void CustomerLoad(){
         
         int x;
         
         try{ 
             pst = con.prepareStatement("select * from CustomerOrder");
             rs = pst.executeQuery();
             
             ResultSetMetaData rsd = (ResultSetMetaData) rs.getMetaData(); //import com.mysql.cj.jdbc.result.ResultSetMetaData
             x = rsd.getColumnCount();
             
             DefaultTableModel dtm = (DefaultTableModel)JTableCustomer.getModel(); //import javax.swing.table.DefaultTableModel
             dtm.setRowCount(0); 
             
             while(rs.next()){
                 Vector vec = new Vector(); //import the java.util.Vector
                 
                 for(int i = 1; i<=1; i++){ //Now write all the respective fields in the database 'CustomerOrder' in order and this iterates through 'i'.
                     vec.add(rs.getString("CustomerID"));
                     vec.add(rs.getString("Name"));
                     vec.add(rs.getString("Category"));
                     vec.add(rs.getString("Price"));
                     vec.add(rs.getString("Qty"));
                     vec.add(rs.getString("Total"));
                     }
                 dtm.addRow(vec); //Delivers the rows in the 'vec' object above from the MySQL database 'CustomerOrder' to be visible in the jTable here.
             }  
         } catch(SQLException ex){
             Logger.getLogger(Driver.class.getName()).log(Level.SEVERE, null, ex);
         }
     }       
        
      public void SalesLoad(){
         
         int x;
         
         try{ 
             pst = con.prepareStatement("select * from Sales");
             rs = pst.executeQuery();
             
             ResultSetMetaData rsd = (ResultSetMetaData) rs.getMetaData();
             x = rsd.getColumnCount();
             
             DefaultTableModel dtm = (DefaultTableModel)JTableSales.getModel();
             dtm.setRowCount(0);
             
             while(rs.next()){
                 Vector vec = new Vector(); 
                 
                 for(int i = 1; i<=1; i++){
                     vec.add(rs.getString("CustomerID"));
                     vec.add(rs.getString("Date"));
                     vec.add(rs.getString("Total"));
                     vec.add(rs.getString("Paid"));
                     vec.add(rs.getString("Balance"));
                     }
                 dtm.addRow(vec);   
             }  
         } catch(SQLException ex){
             Logger.getLogger(Driver.class.getName()).log(Level.SEVERE, null, ex);
         }
     }
         
      public void MessagesLoad(){
         
         int x;
         
         try{ 
             pst = con.prepareStatement("select * from CustomerReview");
             rs = pst.executeQuery();
             
             ResultSetMetaData rsd = (ResultSetMetaData) rs.getMetaData();
             x = rsd.getColumnCount();
             
             DefaultTableModel dtm = (DefaultTableModel)JTableMessage.getModel();
             dtm.setRowCount(0);
             
             while(rs.next()){
                 Vector vec = new Vector();
                 
                 for(int i = 1; i<=1; i++){
                     vec.add(rs.getString("Date"));
                     vec.add(rs.getString("Message"));
                     }
                 dtm.addRow(vec);   
             }  
         } catch(SQLException ex){
             Logger.getLogger(Driver.class.getName()).log(Level.SEVERE, null, ex);
         }
     }
    
    
      
    // Method to get the number of the last row from the tables to display on the labels
   // Credits: UniqueDeveloper on YouTube: part 11 of library management system.
    public void setDataToCards(){
        
        Statement st = null;
        ResultSet rs = null;
        
        long l = System.currentTimeMillis();
        Date todaysDate = new Date(1);
        
        try{
         Class.forName("com.mysql.cj.jdbc.Driver");
          con = DriverManager.getConnection("jdbc:mysql://localhost:3307/Restaurant", "root", "");
           st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
           rs = st.executeQuery("select * from Employee");
           rs.last();
           lbl_Employees.setText(Integer.toString(rs.getRow()));
          
           rs = st.executeQuery("select * from Category");
           rs.last();
           lbl_Categories.setText(Integer.toString(rs.getRow()));
           
           rs = st.executeQuery("select * from Product");
           rs.last();
           lbl_Products.setText(Integer.toString(rs.getRow()));
           
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    
    public void showPieChart(){
        
      //Create Dataset
      DefaultPieDataset barDataset = new DefaultPieDataset(); // import all necessary jfreechart components!
      
      try{
          con = DriverManager.getConnection("jdbc:mysql://localhost:3307/Restaurant", "root", "");
          String sql = "select Total, count(*) as count from Sales group by CustomerID";
          Statement st = con.createStatement();
          ResultSet rs = st.executeQuery(sql);
          while(rs.next()){
              barDataset.setValue(rs.getString("Total"), new Double(rs.getDouble("count")));
          }
          
      }catch (Exception e){
          e.printStackTrace();
      }

       //Create Pie Chart
       JFreeChart piechart = ChartFactory.createPieChart3D("Customers' Spending",barDataset, false,true,false);
      
        PiePlot piePlot =(PiePlot) piechart.getPlot();
       
        piePlot.setBackgroundPaint(Color.white);
        
        //Create chartPanel to display Pie Chart
        ChartPanel barChartPanel = new ChartPanel(piechart);
        panelPieChart.removeAll();
        panelPieChart.add(barChartPanel, BorderLayout.CENTER);
        panelPieChart.validate();
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSeparator1 = new javax.swing.JSeparator();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Exit = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        PanelManageEmployees = new javax.swing.JPanel();
        PanelHP = new javax.swing.JPanel();
        HomePage = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        PanelEmployees = new javax.swing.JPanel();
        lbl_ManageEmployees = new javax.swing.JLabel();
        PanelContactSuppliers = new javax.swing.JPanel();
        lbl_ContactSuppliers = new javax.swing.JLabel();
        PanelAddNewCategory = new javax.swing.JPanel();
        lbl_AddNewCategory = new javax.swing.JLabel();
        PanelAddNewProduct = new javax.swing.JPanel();
        lbl_AddNewProduct = new javax.swing.JLabel();
        PanelManageProducts = new javax.swing.JPanel();
        lbl_ManageProducts = new javax.swing.JLabel();
        PanelLogout = new javax.swing.JPanel();
        lbl_Logout = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        panelPieChart = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        lbl_Employees = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        lbl_Categories = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        lbl_Products = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        JTableSales = new javax.swing.JTable();
        jLabel23 = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jPanel19 = new javax.swing.JPanel();
        jPanel22 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        JTableCustomer = new javax.swing.JTable();
        jLabel26 = new javax.swing.JLabel();
        jPanel23 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        date = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        time = new javax.swing.JLabel();
        panelLineChart = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        JTableMessage = new javax.swing.JTable();
        jLabel10 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(165, 192, 255));

        jLabel1.setFont(new java.awt.Font("Lucida Grande", 0, 21)); // NOI18N
        jLabel1.setText("Welcome, Admin");

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setIcon(new javax.swing.ImageIcon("/Users/joni/Downloads/icons8-user-48.png")); // NOI18N

        Exit.setFont(new java.awt.Font("Lucida Grande", 1, 24)); // NOI18N
        Exit.setForeground(new java.awt.Color(204, 0, 0));
        Exit.setText("x");
        Exit.setBorder(javax.swing.BorderFactory.createCompoundBorder());
        Exit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ExitMouseClicked(evt);
            }
        });

        jLabel4.setIcon(new javax.swing.ImageIcon("/Users/joni/Downloads/icons8-menu-50.png")); // NOI18N

        jLabel5.setIcon(new javax.swing.ImageIcon("/Users/joni/Downloads/icons8-vertical-line-64.png")); // NOI18N

        jLabel6.setFont(new java.awt.Font("Devanagari MT", 0, 28)); // NOI18N
        jLabel6.setText("Olive & Bread - Restaurant Management System");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 424, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addGap(64, 64, 64)
                .addComponent(Exit, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(14, 14, 14))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 68, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2)))
                    .addComponent(Exit, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1440, 80));

        PanelManageEmployees.setBackground(new java.awt.Color(78, 78, 78));
        PanelManageEmployees.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        PanelHP.setBackground(new java.awt.Color(220, 44, 0));
        PanelHP.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PanelHP.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        HomePage.setFont(new java.awt.Font("Lucida Grande", 1, 16)); // NOI18N
        HomePage.setForeground(new java.awt.Color(255, 255, 255));
        HomePage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/home_24px.png"))); // NOI18N
        HomePage.setText(" Home Page");
        HomePage.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                HomePageMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                HomePageMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                HomePageMouseExited(evt);
            }
        });
        PanelHP.add(HomePage, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 240, 60));

        PanelManageEmployees.add(PanelHP, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 260, 60));

        jPanel12.setBackground(new java.awt.Color(78, 78, 78));
        jPanel12.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel12.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setFont(new java.awt.Font("Lucida Grande", 1, 15)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(185, 185, 185));
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/icons8-salt-bae-26.png"))); // NOI18N
        jLabel8.setText(" Olive & Bread Restaurant");
        jPanel12.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 240, 60));

        PanelManageEmployees.add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 250, 60));

        PanelEmployees.setBackground(new java.awt.Color(78, 78, 78));
        PanelEmployees.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PanelEmployees.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PanelEmployeesMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                PanelEmployeesMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                PanelEmployeesMouseExited(evt);
            }
        });
        PanelEmployees.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbl_ManageEmployees.setFont(new java.awt.Font("Lucida Grande", 1, 15)); // NOI18N
        lbl_ManageEmployees.setForeground(new java.awt.Color(185, 185, 185));
        lbl_ManageEmployees.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/icons8_Conference_26px.png"))); // NOI18N
        lbl_ManageEmployees.setText(" Manage Employees");
        lbl_ManageEmployees.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbl_ManageEmployeesMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lbl_ManageEmployeesMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lbl_ManageEmployeesMouseExited(evt);
            }
        });
        PanelEmployees.add(lbl_ManageEmployees, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 240, 60));

        PanelManageEmployees.add(PanelEmployees, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 210, 250, 60));

        PanelContactSuppliers.setBackground(new java.awt.Color(78, 78, 78));
        PanelContactSuppliers.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PanelContactSuppliers.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbl_ContactSuppliers.setFont(new java.awt.Font("Lucida Grande", 1, 15)); // NOI18N
        lbl_ContactSuppliers.setForeground(new java.awt.Color(185, 185, 185));
        lbl_ContactSuppliers.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/icons8_Sell_26px.png"))); // NOI18N
        lbl_ContactSuppliers.setText(" Contact Suppliers");
        lbl_ContactSuppliers.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbl_ContactSuppliersMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lbl_ContactSuppliersMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lbl_ContactSuppliersMouseExited(evt);
            }
        });
        PanelContactSuppliers.add(lbl_ContactSuppliers, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 240, 60));

        PanelManageEmployees.add(PanelContactSuppliers, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 270, 250, 60));

        PanelAddNewCategory.setBackground(new java.awt.Color(78, 78, 78));
        PanelAddNewCategory.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PanelAddNewCategory.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbl_AddNewCategory.setFont(new java.awt.Font("Lucida Grande", 1, 15)); // NOI18N
        lbl_AddNewCategory.setForeground(new java.awt.Color(185, 185, 185));
        lbl_AddNewCategory.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/icons8_View_Details_26px.png"))); // NOI18N
        lbl_AddNewCategory.setText(" Add New Category");
        lbl_AddNewCategory.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbl_AddNewCategoryMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lbl_AddNewCategoryMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lbl_AddNewCategoryMouseExited(evt);
            }
        });
        PanelAddNewCategory.add(lbl_AddNewCategory, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 240, 60));

        PanelManageEmployees.add(PanelAddNewCategory, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 330, 250, 60));

        PanelAddNewProduct.setBackground(new java.awt.Color(78, 78, 78));
        PanelAddNewProduct.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PanelAddNewProduct.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbl_AddNewProduct.setFont(new java.awt.Font("Lucida Grande", 1, 15)); // NOI18N
        lbl_AddNewProduct.setForeground(new java.awt.Color(185, 185, 185));
        lbl_AddNewProduct.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/icons8_Return_Purchase_26px.png"))); // NOI18N
        lbl_AddNewProduct.setText(" Add New Product");
        lbl_AddNewProduct.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbl_AddNewProductMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lbl_AddNewProductMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lbl_AddNewProductMouseExited(evt);
            }
        });
        PanelAddNewProduct.add(lbl_AddNewProduct, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 240, 60));

        PanelManageEmployees.add(PanelAddNewProduct, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 390, -1, 60));

        PanelManageProducts.setBackground(new java.awt.Color(78, 78, 78));
        PanelManageProducts.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PanelManageProducts.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbl_ManageProducts.setFont(new java.awt.Font("Lucida Grande", 1, 15)); // NOI18N
        lbl_ManageProducts.setForeground(new java.awt.Color(185, 185, 185));
        lbl_ManageProducts.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/icons8_Read_Online_26px.png"))); // NOI18N
        lbl_ManageProducts.setText(" Manage Products");
        lbl_ManageProducts.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbl_ManageProductsMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lbl_ManageProductsMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lbl_ManageProductsMouseExited(evt);
            }
        });
        PanelManageProducts.add(lbl_ManageProducts, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 240, 60));

        PanelManageEmployees.add(PanelManageProducts, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 450, 250, 60));

        PanelLogout.setBackground(new java.awt.Color(129, 129, 243));
        PanelLogout.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PanelLogout.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbl_Logout.setFont(new java.awt.Font("Lucida Grande", 1, 15)); // NOI18N
        lbl_Logout.setForeground(new java.awt.Color(255, 255, 255));
        lbl_Logout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/icons8_Exit_26px.png"))); // NOI18N
        lbl_Logout.setText(" Logout");
        lbl_Logout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbl_LogoutMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lbl_LogoutMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lbl_LogoutMouseExited(evt);
            }
        });
        PanelLogout.add(lbl_Logout, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 240, 60));

        PanelManageEmployees.add(PanelLogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 510, 260, 60));

        jLabel15.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(185, 185, 185));
        jLabel15.setText("Features");
        PanelManageEmployees.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 100, 40));

        jPanel1.add(PanelManageEmployees, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 250, 720));

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));

        panelPieChart.setLayout(new java.awt.BorderLayout());

        jPanel6.setBackground(new java.awt.Color(165, 192, 255));

        jPanel9.setBackground(new java.awt.Color(232, 232, 232));

        jLabel17.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabel17.setText("Number of Employees");

        lbl_Employees.setFont(new java.awt.Font("Silom", 1, 24)); // NOI18N
        lbl_Employees.setForeground(new java.awt.Color(95, 95, 95));
        lbl_Employees.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/icons8-crowd-50.png"))); // NOI18N
        lbl_Employees.setText(" 8");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel17)
                        .addGap(19, 19, 19))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                        .addComponent(lbl_Employees, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(67, 67, 67))))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addComponent(jLabel17)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lbl_Employees, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addGap(0, 15, Short.MAX_VALUE)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel7.setBackground(new java.awt.Color(169, 169, 251));

        jPanel10.setBackground(new java.awt.Color(232, 232, 232));

        jLabel19.setBackground(new java.awt.Color(153, 153, 153));
        jLabel19.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(31, 31, 31));
        jLabel19.setText("Number of Categories");

        lbl_Categories.setFont(new java.awt.Font("Silom", 1, 24)); // NOI18N
        lbl_Categories.setForeground(new java.awt.Color(95, 95, 95));
        lbl_Categories.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/icons8-cookbook-50.png"))); // NOI18N
        lbl_Categories.setText("8");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel19)
                .addContainerGap(19, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lbl_Categories)
                .addGap(77, 77, 77))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addComponent(jLabel19)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lbl_Categories, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19))
        );

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addGap(0, 15, Short.MAX_VALUE)
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel8.setBackground(new java.awt.Color(145, 145, 242));

        jPanel11.setBackground(new java.awt.Color(232, 232, 232));

        jLabel21.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(43, 43, 43));
        jLabel21.setText("Number of Products");

        lbl_Products.setFont(new java.awt.Font("Silom", 1, 24)); // NOI18N
        lbl_Products.setForeground(new java.awt.Color(95, 95, 95));
        lbl_Products.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/icons8-cooking-book-50.png"))); // NOI18N
        lbl_Products.setText("8");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel21)
                .addContainerGap(28, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lbl_Products)
                .addGap(71, 71, 71))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addComponent(jLabel21)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lbl_Products, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addGap(0, 15, Short.MAX_VALUE)
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel13.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        JTableSales.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "CustomerID", "Date", "Total", "Paid", "Change"
            }
        ));
        jScrollPane1.setViewportView(JTableSales);

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 730, Short.MAX_VALUE)
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 180, Short.MAX_VALUE)
        );

        jPanel13.add(jPanel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 730, 180));

        jLabel23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/food (18).jpg"))); // NOI18N
        jPanel13.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 730, 220));

        jPanel17.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel24.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jLabel24.setText("Restaurant's Sales Table");

        jLabel25.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jLabel25.setText("Customer's Order Table");

        jSeparator2.setBackground(new java.awt.Color(0, 102, 102));
        jSeparator2.setForeground(new java.awt.Color(0, 153, 153));
        jSeparator2.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jPanel19.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        JTableCustomer.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "CustomerID", "ProductName", "Category", "Price", "Quantity", "Subtotal"
            }
        ));
        jScrollPane2.setViewportView(JTableCustomer);

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 730, Short.MAX_VALUE)
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        );

        jPanel19.add(jPanel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 730, 200));

        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/food (16).jpg"))); // NOI18N
        jPanel19.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 730, 240));

        jPanel23.setBackground(new java.awt.Color(189, 205, 244));
        jPanel23.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(156, 186, 255), 3));
        jPanel23.setForeground(new java.awt.Color(0, 153, 204));

        jPanel14.setBackground(new java.awt.Color(189, 205, 244));

        date.setFont(new java.awt.Font("Lucida Grande", 1, 21)); // NOI18N
        date.setForeground(new java.awt.Color(51, 51, 51));
        date.setText("Date");

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(date, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel15.setBackground(new java.awt.Color(189, 205, 244));

        time.setFont(new java.awt.Font("Lucida Grande", 1, 21)); // NOI18N
        time.setForeground(new java.awt.Color(51, 51, 51));
        time.setText("Time");

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                .addGap(0, 12, Short.MAX_VALUE)
                .addComponent(time))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(time)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel23Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        panelLineChart.setBackground(new java.awt.Color(255, 255, 255));
        panelLineChart.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jLabel9.setText("Customer Reviews and Messages");
        panelLineChart.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, -1, 30));

        JTableMessage.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Date", "Message"
            }
        ));
        jScrollPane3.setViewportView(JTableMessage);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 390, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 240, Short.MAX_VALUE)
        );

        panelLineChart.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 390, 240));

        jLabel10.setIcon(new javax.swing.ImageIcon("/Users/joni/Downloads/coffee-break (1).jpg")); // NOI18N
        panelLineChart.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 390, 280));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel24)
                                .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel25))
                            .addComponent(jPanel19, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jSeparator2)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(panelLineChart, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(panelPieChart, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(24, 24, 24)
                        .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(55, 55, 55)
                        .addComponent(jPanel23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jPanel23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(panelPieChart, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(panelLineChart, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel24)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel25)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(17, 21, Short.MAX_VALUE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jSeparator2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 705, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel5Layout.createSequentialGroup()
                                .addGap(387, 387, 387)
                                .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 1, Short.MAX_VALUE))))
        );

        jPanel1.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 80, 1190, 720));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 796, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ExitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitMouseClicked
        // TODO add your handling code here:
              JFrame frame = new JFrame("EXIT");
       if(JOptionPane.showConfirmDialog(frame,"Are you sure you want to Exit?", "Exit", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION)
       {
           System.exit(0);
       }                      
    }//GEN-LAST:event_ExitMouseClicked

    private void PanelEmployeesMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelEmployeesMouseEntered
        // TODO add your handling code here:
        
    }//GEN-LAST:event_PanelEmployeesMouseEntered

    private void PanelEmployeesMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelEmployeesMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_PanelEmployeesMouseExited

    private void PanelEmployeesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelEmployeesMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_PanelEmployeesMouseClicked

    private void lbl_ManageEmployeesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_ManageEmployeesMouseClicked
        // TODO add your handling code here:
        Employees employees = new Employees();
        employees.setVisible(true);
        dispose();
    }//GEN-LAST:event_lbl_ManageEmployeesMouseClicked

    private void lbl_ManageEmployeesMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_ManageEmployeesMouseEntered
        // TODO add your handling code here:
        PanelEmployees.setBackground(EnterColor);
    }//GEN-LAST:event_lbl_ManageEmployeesMouseEntered

    private void lbl_ManageEmployeesMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_ManageEmployeesMouseExited
        // TODO add your handling code here:
        PanelEmployees.setBackground(ExitColor);
    }//GEN-LAST:event_lbl_ManageEmployeesMouseExited

    private void lbl_ContactSuppliersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_ContactSuppliersMouseClicked
        // TODO add your handling code here:
        Supplier suppliers = new Supplier();
        suppliers.setVisible(true);
        dispose();
    }//GEN-LAST:event_lbl_ContactSuppliersMouseClicked

    private void lbl_ContactSuppliersMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_ContactSuppliersMouseEntered
        // TODO add your handling code here:
        PanelContactSuppliers.setBackground(EnterColor);
    }//GEN-LAST:event_lbl_ContactSuppliersMouseEntered

    private void lbl_ContactSuppliersMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_ContactSuppliersMouseExited
        // TODO add your handling code here:
        PanelContactSuppliers.setBackground(ExitColor);
    }//GEN-LAST:event_lbl_ContactSuppliersMouseExited

    private void lbl_AddNewCategoryMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_AddNewCategoryMouseClicked
        // TODO add your handling code here:
        AddCategory categories = new AddCategory();
        categories.setVisible(true);
        dispose();
    }//GEN-LAST:event_lbl_AddNewCategoryMouseClicked

    private void lbl_AddNewCategoryMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_AddNewCategoryMouseEntered
        // TODO add your handling code here:
        PanelAddNewCategory.setBackground(EnterColor);
    }//GEN-LAST:event_lbl_AddNewCategoryMouseEntered

    private void lbl_AddNewCategoryMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_AddNewCategoryMouseExited
        // TODO add your handling code here:
        PanelAddNewCategory.setBackground(ExitColor);
    }//GEN-LAST:event_lbl_AddNewCategoryMouseExited

    private void lbl_AddNewProductMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_AddNewProductMouseClicked
        // TODO add your handling code here:
        AddProduct products = new AddProduct();
        products.setVisible(true);
        dispose();
    }//GEN-LAST:event_lbl_AddNewProductMouseClicked

    private void lbl_AddNewProductMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_AddNewProductMouseEntered
        // TODO add your handling code here:
        PanelAddNewProduct.setBackground(EnterColor);
    }//GEN-LAST:event_lbl_AddNewProductMouseEntered

    private void lbl_AddNewProductMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_AddNewProductMouseExited
        // TODO add your handling code here:
        PanelAddNewProduct.setBackground(ExitColor);
    }//GEN-LAST:event_lbl_AddNewProductMouseExited

    private void lbl_ManageProductsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_ManageProductsMouseClicked
        // TODO add your handling code here:
        ManageProduct manageproducts = new ManageProduct();
        manageproducts.setVisible(true);
        dispose();
    }//GEN-LAST:event_lbl_ManageProductsMouseClicked

    private void lbl_ManageProductsMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_ManageProductsMouseEntered
        // TODO add your handling code here:
        PanelManageProducts.setBackground(EnterColor);
    }//GEN-LAST:event_lbl_ManageProductsMouseEntered

    private void lbl_ManageProductsMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_ManageProductsMouseExited
        // TODO add your handling code here:
        PanelManageProducts.setBackground(ExitColor);
    }//GEN-LAST:event_lbl_ManageProductsMouseExited

    private void lbl_LogoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_LogoutMouseClicked
        // TODO add your handling code here:
        HomePage homepage = new HomePage();
        homepage.setVisible(true);
        dispose();
    }//GEN-LAST:event_lbl_LogoutMouseClicked

    private void lbl_LogoutMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_LogoutMouseEntered
        // TODO add your handling code here:
        PanelLogout.setBackground(LogoutEnterColor);
    }//GEN-LAST:event_lbl_LogoutMouseEntered

    private void lbl_LogoutMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_LogoutMouseExited
        // TODO add your handling code here:
        PanelLogout.setBackground(LogoutExitColor);      
    }//GEN-LAST:event_lbl_LogoutMouseExited

    private void HomePageMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_HomePageMouseClicked
        // TODO add your handling code here:
        HomePage hp = new HomePage();
        hp.setVisible(true);
        dispose();
    }//GEN-LAST:event_HomePageMouseClicked

    private void HomePageMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_HomePageMouseEntered
        // TODO add your handling code here:
        PanelHP.setBackground(ExitBack);
    }//GEN-LAST:event_HomePageMouseEntered

    private void HomePageMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_HomePageMouseExited
        // TODO add your handling code here:
        PanelHP.setBackground(EnterBack);
    }//GEN-LAST:event_HomePageMouseExited

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Exit;
    private javax.swing.JLabel HomePage;
    private javax.swing.JTable JTableCustomer;
    private javax.swing.JTable JTableMessage;
    private javax.swing.JTable JTableSales;
    private javax.swing.JPanel PanelAddNewCategory;
    private javax.swing.JPanel PanelAddNewProduct;
    private javax.swing.JPanel PanelContactSuppliers;
    private javax.swing.JPanel PanelEmployees;
    private javax.swing.JPanel PanelHP;
    private javax.swing.JPanel PanelLogout;
    private javax.swing.JPanel PanelManageEmployees;
    private javax.swing.JPanel PanelManageProducts;
    private javax.swing.JLabel date;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JLabel lbl_AddNewCategory;
    private javax.swing.JLabel lbl_AddNewProduct;
    private javax.swing.JLabel lbl_Categories;
    private javax.swing.JLabel lbl_ContactSuppliers;
    private javax.swing.JLabel lbl_Employees;
    private javax.swing.JLabel lbl_Logout;
    private javax.swing.JLabel lbl_ManageEmployees;
    private javax.swing.JLabel lbl_ManageProducts;
    private javax.swing.JLabel lbl_Products;
    private javax.swing.JPanel panelLineChart;
    private javax.swing.JPanel panelPieChart;
    private javax.swing.JLabel time;
    // End of variables declaration//GEN-END:variables

   // @Override
  
    @Override
    public void run() { // Clock
       while(true){
           try{
               Calendar c = Calendar.getInstance();
               minute = c.get(Calendar.MINUTE);
               second = c.get(Calendar.SECOND);
               hour = c.get(Calendar.HOUR_OF_DAY);
              
               if(hour>12){
                   hour = hour-12;
               }
               
               year = c.get(Calendar.YEAR);
               month = c.get(Calendar.MONTH);
               day = c.get(Calendar.DAY_OF_MONTH);

               SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss a");
               SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
               
               Date dat = c.getTime();
               timestr = sdf.format(dat);
               yearstr = df.format(dat);
               date.setText(yearstr);
               time.setText(timestr);            

           }catch(Exception e){
              // e.printStackTrace();
           }
       }
    }
}
